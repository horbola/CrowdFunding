@include('layouts/charity/header')  
 @yield('content') 
@include('layouts/charity/footer')  
 