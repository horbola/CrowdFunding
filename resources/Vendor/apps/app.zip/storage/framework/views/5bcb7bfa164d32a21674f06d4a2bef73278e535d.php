<?php $__env->startSection('title'); ?> <?php if( ! empty($title)): ?> <?php echo e($title); ?> | <?php endif; ?> ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8## <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="campaign-details-wrap">
        <?php echo $__env->make('single_campaign_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="container">

            <?php echo e(Form::open(['class' => 'form-horizontal', 'files' => true])); ?>

            <div class="row">
                <div class="col-md-8">

                    <div class="checkout-wrap">

                        <div class="contributing-to">
                            <p class="contributing-to-name"><strong> <?php echo app('translator')->getFromJson('app.you_are_contributing_to'); ?> <?php echo e($campaign->user->name); ?></strong></p>
                            <h3><?php echo e($campaign->title); ?></h3>

                            <?php if( ! Auth::check()): ?>
                                <p class="guest_checkout_text"><strong> <?php echo app('translator')->getFromJson('app.guest_checkout'); ?> <span class="text-muted"><?php echo app('translator')->getFromJson('app.or'); ?></span> <a href="<?php echo e(route('login')); ?>"><?php echo app('translator')->getFromJson('app.log_in'); ?></a> </strong></p>
                            <?php endif; ?>
                        </div>

                        <div class="form-group <?php echo e($errors->has('full_name')? 'has-error':''); ?>">
                            <div class="col-sm-6">
                                <input type="text" class="form-control" id="full_name" value="<?php if(Auth::check()): ?><?php echo e(auth()->user()->name); ?><?php else: ?><?php echo e(old('full_name')); ?><?php endif; ?>" name="full_name" placeholder="<?php echo app('translator')->getFromJson('app.full_name'); ?>" required="required">
                                <?php echo $errors->has('full_name')? '<p class="help-block">'.$errors->first('full_name').'</p>':''; ?>

                            </div>
                            <div class="col-sm-6">
                                <input type="email" class="form-control" id="email" value="<?php if(Auth::check()): ?><?php echo e(auth()->user()->email); ?><?php else: ?><?php echo e(old('email')); ?><?php endif; ?>" name="email" placeholder="<?php echo app('translator')->getFromJson('app.email'); ?>" required="required">
                                <?php echo $errors->has('email')? '<p class="help-block">'.$errors->first('email').'</p>':''; ?>

                            </div>
                            <div class="col-sm-6 pt-20">
                                <input type="phone" class="form-control" id="phone" value="<?php if(Auth::check()): ?><?php echo e(auth()->user()->phone); ?><?php else: ?><?php echo e(old('phone')); ?><?php endif; ?>" name="phone" placeholder="<?php echo app('translator')->getFromJson('app.phone'); ?>" required="required">
                                <?php echo $errors->has('phone')? '<p class="help-block">'.$errors->first('phone').'</p>':''; ?>

                            </div>
                            <div class="col-sm-6 pt-20">
                                <input type="text" class="form-control" id="address" value="<?php if(Auth::check()): ?><?php echo e(auth()->user()->address); ?><?php else: ?><?php echo e(old('address')); ?><?php endif; ?>" name="address" placeholder="address" required="required">
                                <?php echo $errors->has('address')? '<p class="help-block">'.$errors->first('address').'</p>':''; ?>

                            </div>
                        </div>

                        <p>
                            <strong><?php echo app('translator')->getFromJson('app.contribution_appearance'); ?></strong> <br />
                            <?php echo app('translator')->getFromJson('app.name_displayed_publicly'); ?>
                        </p>

                        <div class="form-group <?php echo e($errors->has('contributor_name_display')? 'has-error':''); ?>">
                            <div class="col-sm-12">
                                <div class="name_display_wrap">
                                    <input type="hidden" name="contributor_name_display" value="full_name">
                                    

                                </div>
                            </div>
                        </div>

                    </div>

                </div>

                <div class="col-md-4">

                    <div class="donation-summery">

                        <div class="panel panel-default">

                            <div class="panel-heading">
                                <h4>Summery</h4>
                            </div>

                            <div class="panel-body">

                                <?php 
                                    if(session('cart.cart_type') == 'reward'){
                                    $donation_amount = $reward->amount;
                                    }else{
                                    $donation_amount = session('cart.amount');
                                    }
                                 ?>

                                <table class="table border-none">
                                    <tr>
                                        <td class="border-none"><?php echo app('translator')->getFromJson('app.donation'); ?> : <?php echo e($campaign->title); ?></td>
                                        <td class="border-none"><?php echo e(get_amount($donation_amount)); ?></td>
                                    </tr>
                                    <tr>
                                        <th><?php echo app('translator')->getFromJson('app.total'); ?></th>
                                        <th><?php echo e(get_amount($donation_amount)); ?></th>
                                    </tr>
                                </table>


                                <?php if(session('cart.cart_type') == 'reward'): ?>
                                    <div class="reward-box">
                                        <h4><?php echo app('translator')->getFromJson('app.selected_reward'); ?></h4>

                                        <a href="javascript:;">
                                            <span class="reward-amount"><?php echo app('translator')->getFromJson('app.pledge'); ?> <strong><?php echo e(get_amount($reward->amount)); ?></strong></span>
                                            <span class="reward-text"><?php echo e($reward->description); ?></span>
                                            <span class="reward-estimated-delivery"> <?php echo app('translator')->getFromJson('app.estimated_delivery'); ?>: <?php echo e(date('F Y', strtotime($reward->estimated_delivery))); ?></span>
                                        </a>
                                    </div>
                                <?php endif; ?>

                                <p class="text-muted"> <?php echo app('translator')->getFromJson('app.agree_terms_policy'); ?> </p>

                                <button type="submit" class="btn-block btn btn-primary btn-lg"><?php echo app('translator')->getFromJson('app.submit_payment'); ?></button>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

            <?php echo e(Form::close()); ?>


        </div>

    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>

    <script>
        $(function(){
            $(document).on('click', '.donate-amount-placeholder ul li', function(e){
                $(this).closest('form').find($('[name="amount"]')).val($(this).data('value'));
            });
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.charity.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>