<?php $__env->startSection('title'); ?> <?php if(! empty($title)): ?> <?php echo e($title); ?> <?php endif; ?> - ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8## <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <div class="col-md-12">
                    <?php if( ! empty($title)): ?>
                        <div class="row">
                            <div class="col-lg-12">
                                <h1 class="page-header"> <?php echo e($title); ?>  </h1>
                            </div> <!-- /.col-lg-12 -->
                        </div> <!-- /.row -->
                    <?php endif; ?>

                    <?php echo $__env->make('admin.flash_msg', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <div class="row">
                        <div class="col-xs-12">
                            <div class="profile-avatar">
                                <img src="<?php echo e($user->get_gravatar(100)); ?>" class="img-thumbnail img-circle" width="100" />
                            </div>

                            <table class="table table-bordered table-striped">

                                <tr>
                                    <th><?php echo app('translator')->getFromJson('app.name'); ?></th>
                                    <td><?php echo e($user->name); ?></td>
                                </tr>

                                <tr>
                                    <th><?php echo app('translator')->getFromJson('app.email'); ?></th>
                                    <td><?php echo e($user->email); ?></td>
                                </tr>
                                <tr>
                                    <th><?php echo app('translator')->getFromJson('app.gender'); ?></th>
                                    <td><?php echo e(ucfirst($user->gender)); ?></td>
                                </tr>
                                <tr>
                                    <th><?php echo app('translator')->getFromJson('app.phone'); ?></th>
                                    <td><?php echo e($user->phone); ?></td>
                                </tr>
                                <tr>
                                    <th><?php echo app('translator')->getFromJson('app.address'); ?></th>
                                    <td><?php echo e($user->address); ?></td>
                                </tr>
                                <tr>
                                    <th><?php echo app('translator')->getFromJson('app.country'); ?></th>
                                    <td>
                                        <?php if($user->country): ?>
                                            <?php echo e($user->country->name); ?>

                                        <?php endif; ?>
                                    </td>
                                </tr>

                                <tr>
                                    <th><?php echo app('translator')->getFromJson('app.created_at'); ?></th>
                                    <td><?php echo e($user->signed_up_datetime()); ?></td>
                                </tr>
                                <tr>
                                    <th><?php echo app('translator')->getFromJson('app.status'); ?></th>
                                    <td><?php echo e($user->status_context()); ?></td>
                                </tr>
                            </table>

                            <a href="<?php echo e(route('profile_edit')); ?>"><i class="fa fa-pencil-square-o"></i> <?php echo app('translator')->getFromJson('app.edit'); ?> </a>

                        </div>
                    </div>
    </div>   <!-- /#page-wrapper -->
</div>   <!-- /#wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>