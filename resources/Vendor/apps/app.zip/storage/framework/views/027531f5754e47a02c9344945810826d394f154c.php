<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon and Touch Icons -->
    <link href="<?php echo e(asset('favicon.ico')); ?>" rel="shortcut icon" type="image/png">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title> <?php echo $__env->yieldContent('title'); ?> <?php echo e(get_option('site_title')); ?> <?php echo $__env->yieldSection(); ?> </title>

        <!-- Bootstrap Core CSS -->
        <link href="<?php echo e(asset('admin/css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/bootstrap-datepicker/css/bootstrap-datetimepicker.css')); ?>">

        <!-- MetisMenu CSS -->
        <link href="<?php echo e(asset('admin/css/metisMenu.min.css')); ?>" rel="stylesheet">

        <!-- Timeline CSS -->
        <link href="<?php echo e(asset('admin/css/timeline.css')); ?>" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="<?php echo e(asset('admin/css/startmin.css')); ?>" rel="stylesheet">

        <!-- Morris Charts CSS -->
        <link href="<?php echo e(asset('admin/css/morris.css')); ?>" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="<?php echo e(asset('admin/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    
        <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/toastr/toastr.min.css')); ?>">
         <?php echo $__env->yieldContent('page-css'); ?>

        <?php if(get_option('additional_css')): ?>
            <style type="text/css">
                <?php echo e(get_option('additional_css')); ?>

            </style>
            <?php endif; ?>
                <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Scripts -->
        <script>
            window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>;
        </script>
    </head>
    <body>

        <div id="wrapper">
            <!-- Navigation -->
            <?php echo $__env->make('layouts.admin.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <!-- /#wrapper -->

        <!-- jQuery -->
        <script src="<?php echo e(asset('admin/js/jquery.min.js')); ?>"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment-with-locales.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="<?php echo e(asset('admin/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/plugins/bootstrap-datepicker/js/bootstrap-datetimepicker.min.js')); ?>"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="<?php echo e(asset('admin/js/metisMenu.min.js')); ?>"></script>

        <!-- Morris Charts JavaScript -->
        <script src="<?php echo e(asset('admin/js/raphael.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/js/morris.min.js')); ?>"></script>
        

        <!-- Custom Theme JavaScript -->
        <script src="<?php echo e(asset('admin/js/startmin.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/plugins/toastr/toastr.min.js')); ?>"></script>

        <!-- Conditional page load script -->
        <?php if(request()->segment(1) === 'dashboard'): ?>
            <script src="<?php echo e(asset('assets/plugins/metisMenu/dist/metisMenu.min.js')); ?>"></script>
            <script>
                $(function() {
                    $('#side-menu').metisMenu();
                });
            </script>
        <?php endif; ?>
        <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
        <script>
            var toastr_options = {closeButton : true};
        </script>
        <script>
            $('.box-campaign-lists').masonry({
                itemSelector : '.box-campaign-item'
            });
        </script>
        <script>
          <?php if(Session::has('message')): ?>
            var type = "<?php echo e(Session::get('alert-type', 'info')); ?>";
            switch(type){
                case 'info':
                    toastr.info("<?php echo e(Session::get('message')); ?>");
                    break;
                
                case 'warning':
                    toastr.warning("<?php echo e(Session::get('message')); ?>");
                    break;

                case 'success':
                    toastr.success("<?php echo e(Session::get('message')); ?>");
                    break;

                case 'error':
                    toastr.error("<?php echo e(Session::get('message')); ?>");
                    break;
            }
          <?php endif; ?>
        </script>
        <?php echo $__env->yieldContent('page-js'); ?>

        <?php if(get_option('additional_js')): ?>
        <?php echo get_option('additional_js'); ?>

        <?php endif; ?>
    </body>
</html>
