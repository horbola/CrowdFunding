<section class="home-get-start" style="padding-bottom: 100px">
    <div class="container">

        <div class="row">
            <div class="col-md-12">
                <div class="home-get-start-content">
                    <h3 class="section-title"><?php echo app('translator')->getFromJson('app.get_started_today'); ?></h3>
                    <p class="sub-title"> <?php echo app('translator')->getFromJson('app.discover_desc'); ?> </p>
                    <div class="get-start-buttons">
                        <a href="<?php echo e(route('browse_categories')); ?>" class="btn btn-success"><?php echo app('translator')->getFromJson('app.discover'); ?></a>
                        <a href="<?php echo e(route('start_campaign')); ?>" class="btn btn-default"><?php echo app('translator')->getFromJson('app.start_a_campaign'); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>