<?php $__env->startSection('title'); ?> <?php if(! empty($title)): ?> <?php echo e($title); ?> <?php endif; ?> - ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8## <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="page-wrapper">
        <div class="col-md-12">

                    <?php if( ! empty($title)): ?>
                        <div class="row">
                            <div class="col-lg-12">
                                <h1 class="page-header"> <?php echo e($title); ?>  </h1>
                            </div> <!-- /.col-lg-12 -->
                        </div> <!-- /.row -->
                    <?php endif; ?>

                    <?php echo $__env->make('admin.flash_msg', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


                       <div class="admin-campaign-lists">

                           <div class="row">
                               <div class="col-md-5">

                               </div>

                               <div class="col-md-7">

                                   <form class="form-inline" method="get" action="">
                                       <div class="form-group">
                                           <input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="<?php echo app('translator')->getFromJson('app.payer_email'); ?>">
                                       </div>
                                       <button type="submit" class="btn btn-default"><?php echo app('translator')->getFromJson('app.search'); ?></button>
                                   </form>

                               </div>
                           </div>

                       </div>

                        <table class="table table-striped table-bordered">

                            <tr>
                                <th><?php echo app('translator')->getFromJson('app.campaign_title'); ?></th>
                                <td><?php echo e($payment->campaign->title); ?></td>
                            </tr>

                            <tr>
                                <th><?php echo app('translator')->getFromJson('app.payer_name'); ?></th>
                                <td><?php echo e($payment->name); ?></td>
                            </tr>
                            <tr>
                                <th><?php echo app('translator')->getFromJson('app.payer_email'); ?></th>
                                <td><?php echo e($payment->email); ?></td>
                            </tr>

                            <tr>
                                <th><?php echo app('translator')->getFromJson('app.amount'); ?></th>
                                <td><?php echo e(get_amount($payment->amount)); ?></td>
                            </tr>

                            <tr>
                                <th><?php echo app('translator')->getFromJson('app.method'); ?></th>
                                <td><?php echo e($payment->payment_method); ?></td>
                            </tr>

                            <tr>
                                <th><?php echo app('translator')->getFromJson('app.currency'); ?></th>
                                <td><?php echo e($payment->currency); ?></td>
                            </tr>

                            <?php if($payment->payment_method == 'stripe'): ?>

                                <tr>
                                    <th><?php echo app('translator')->getFromJson('app.card_last4'); ?></th>
                                    <td><?php echo e($payment->card_last4); ?></td>
                                </tr>

                                <tr>
                                    <th><?php echo app('translator')->getFromJson('app.card_id'); ?></th>
                                    <td><?php echo e($payment->card_id); ?></td>
                                </tr>

                                <tr>
                                    <th><?php echo app('translator')->getFromJson('app.card_brand'); ?></th>
                                    <td><?php echo e($payment->card_brand); ?></td>
                                </tr>

                                <tr>
                                    <th><?php echo app('translator')->getFromJson('app.card_expire'); ?></th>
                                    <td><?php echo e($payment->card_exp_month); ?>,<?php echo e($payment->card_exp_year); ?></td>
                                </tr>

                            <?php endif; ?>


                            <tr>
                                <th><?php echo app('translator')->getFromJson('app.gateway_transaction_id'); ?></th>
                                <td><?php echo e($payment->charge_id_or_token); ?></td>
                            </tr>

                            <tr>
                                <th><?php echo app('translator')->getFromJson('app.time'); ?></th>
                                <td><?php echo e($payment->created_at->format('F d, Y h:i a')); ?></td>
                            </tr>
                        </table>


                        <?php if($payment->reward): ?>
                            <h3><?php echo app('translator')->getFromJson('app.selected_reward'); ?></h3>

                            <table class="table table-striped table-bordered">

                                <tr>
                                    <th><?php echo app('translator')->getFromJson('app.amount'); ?></th>
                                    <td><?php echo e(get_amount($payment->reward->amount)); ?></td>
                                </tr>

                                <tr>
                                    <th><?php echo app('translator')->getFromJson('app.description'); ?></th>
                                    <td><?php echo e($payment->reward->description); ?></td>
                                </tr>
                                <tr>
                                    <th><?php echo app('translator')->getFromJson('app.estimated_delivery'); ?></th>
                                    <td><?php echo e($payment->reward->estimated_delivery); ?></td>
                                </tr>

                            </table>


                        <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>