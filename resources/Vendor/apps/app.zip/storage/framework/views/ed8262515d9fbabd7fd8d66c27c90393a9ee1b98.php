<?php 
$auth_user = \Illuminate\Support\Facades\Auth::user();
 ?>

<div class="navbar-default sidebar" role="navigation">
    <div class="sidebar-nav navbar-collapse">
        <ul class="nav" id="side-menu">
            <li>
                <a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-dashboard fa-fw"></i> <?php echo app('translator')->getFromJson('app.dashboard'); ?></a>
            </li>

            <li>
                <a href="#"><i class="fa fa-bullhorn"></i> <?php echo app('translator')->getFromJson('app.my_campaigns'); ?><span class="fa arrow"></span></a>
                <ul class="nav nav-second-level">
                    <li>  <a href="<?php echo e(route('my_campaigns')); ?>"><?php echo app('translator')->getFromJson('app.my_campaigns'); ?></a> </li>
                    <li>  <a href="<?php echo e(route('start_campaign')); ?>"><?php echo app('translator')->getFromJson('app.start_a_campaign'); ?></a> </li>
                    <li>  <a href="<?php echo e(route('my_pending_campaigns')); ?>"><?php echo app('translator')->getFromJson('app.pending_campaigns'); ?></a> </li>
                </ul>
            </li>

            <?php if($auth_user->is_admin()): ?>
            <li> <a href="<?php echo e(route('categories')); ?>"><i class="fa fa-folder-o"></i> <?php echo app('translator')->getFromJson('app.categories'); ?></a>  </li>
            <li>
                <a href="#"><i class="fa fa-bullhorn"></i> <?php echo app('translator')->getFromJson('app.campaigns'); ?><span class="fa arrow"></span></a>
                <ul class="nav nav-second-level">
                    <li> <a href="<?php echo e(route('all_campaigns')); ?>"><?php echo app('translator')->getFromJson('app.all_campaigns'); ?></a> </li>
                    <li> <a href="<?php echo e(route('staff_picks')); ?>"><?php echo app('translator')->getFromJson('app.staff_picks'); ?></a> </li>
                    <li> <a href="<?php echo e(route('funded')); ?>"><?php echo app('translator')->getFromJson('app.funded'); ?></a> </li>
                    <li> <a href="<?php echo e(route('blocked_campaigns')); ?>"><?php echo app('translator')->getFromJson('app.blocked_campaigns'); ?></a> </li>
                    <li> <a href="<?php echo e(route('pending_campaigns')); ?>"><?php echo app('translator')->getFromJson('app.pending_campaigns'); ?></a> </li>
                    <li> <a href="<?php echo e(route('expired_campaigns')); ?>"><?php echo app('translator')->getFromJson('app.expired_campaigns'); ?></a> </li>
                </ul>
                <!-- /.nav-second-level -->
            </li>

            <li>
                <a href="#"><i class="fa fa-wrench fa-fw"></i> <?php echo app('translator')->getFromJson('app.settings'); ?><span class="fa arrow"></span></a>
                <ul class="nav nav-second-level">
                    <li> <a href="<?php echo e(route('general_settings')); ?>"><?php echo app('translator')->getFromJson('app.general_settings'); ?></a> </li>
                    <li> <a href="<?php echo e(route('payment_settings')); ?>"><?php echo app('translator')->getFromJson('app.payment_settings'); ?></a> </li>
                    <li> <a href="<?php echo e(route('theme_settings')); ?>"><?php echo app('translator')->getFromJson('app.theme_settings'); ?></a> </li>
                    <li> <a href="<?php echo e(route('social_settings')); ?>"><?php echo app('translator')->getFromJson('app.social_settings'); ?></a> </li>
                    <li> <a href="<?php echo e(route('other_settings')); ?>"><?php echo app('translator')->getFromJson('app.other_settings'); ?></a> </li>
                </ul>
                <!-- /.nav-second-level -->
            </li>
            <li> <a href="<?php echo e(route('pages')); ?>"><i class="fa fa-file-word-o"></i> <?php echo app('translator')->getFromJson('app.pages'); ?></a>  </li>
            <?php endif; ?>

            <li> <a href="<?php echo e(route('payments')); ?>"><i class="fa fa-money"></i> <?php echo app('translator')->getFromJson('app.payments'); ?></a>  </li>
            <li> <a href="<?php echo e(route('withdraw')); ?>"><i class="fa fa-credit-card"></i> <?php echo app('translator')->getFromJson('app.withdraw'); ?></a>  </li>
            <li> <a href="<?php echo e(route('profile')); ?>"><i class="fa fa-user"></i> <?php echo app('translator')->getFromJson('app.profile'); ?></a>  </li>
            <li> <a href="<?php echo e(route('change_password')); ?>"><i class="fa fa-lock"></i> <?php echo app('translator')->getFromJson('app.change_password'); ?></a>  </li>

        </ul>
    </div>
    <!-- /.sidebar-collapse -->
</div>
