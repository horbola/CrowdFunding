<?php $__env->startSection('title'); ?> <?php if( ! empty($title)): ?> <?php echo e($title); ?> | <?php endif; ?> ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8## <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="page-wrapper">
                    <?php if( ! empty($title)): ?>
                        <div class="row">
                            <div class="col-lg-12">
                                <h1 class="page-header"> <?php echo e($title); ?> <a href="<?php echo e(route('edit_campaign', $campaign_id)); ?>" class="btn btn-info pull-right"><i class="fa fa-arrow-circle-o-left"></i> <?php echo app('translator')->getFromJson('app.back_to_campaign'); ?></a> </h1>
                            </div> <!-- /.col-lg-12 -->
                        </div> <!-- /.row -->
                    <?php endif; ?>

                    <?php echo $__env->make('admin.flash_msg', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <div class="row">
                        <div class="col-sm-8 col-sm-offset-1 col-xs-12">

                            <?php echo e(Form::open(['class' => 'form-horizontal', 'files' => true])); ?>



                            <div class="form-group <?php echo e($errors->has('title')? 'has-error':''); ?>">
                                <label for="title" class="col-sm-4 control-label"><?php echo app('translator')->getFromJson('app.title'); ?></label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="title" value="<?php echo e(old('title')); ?>" name="title" placeholder="<?php echo app('translator')->getFromJson('app.title'); ?>">
                                    <?php echo $errors->has('title')? '<p class="help-block">'.$errors->first('title').'</p>':''; ?>

                                </div>
                            </div>

                            <div class="form-group <?php echo e($errors->has('description')? 'has-error':''); ?>">
                                <label for="description" class="col-sm-4 control-label"><?php echo app('translator')->getFromJson('app.description'); ?></label>
                                <div class="col-sm-8">
                                    <textarea class="form-control" name="description"><?php echo e(old('description')); ?></textarea>
                                    <?php echo $errors->has('description')? '<p class="help-block">'.$errors->first('description').'</p>':''; ?>

                                </div>
                            </div>


                            <div class="form-group">
                                <div class="col-sm-offset-4 col-sm-8">
                                    <button type="submit" class="btn btn-primary"><?php echo app('translator')->getFromJson('app.save_faq'); ?></button>
                                </div>
                            </div>
                            <?php echo e(Form::close()); ?>


                        </div>

                    </div>

                        <?php if($faqs->count()): ?>
                            <div class="row">
                                <div class="col-xs-12">
                                    <table class="table table-bordered categories-lists">
                                        <tr>
                                            <th><?php echo app('translator')->getFromJson('app.title'); ?> </th>
                                            <th><?php echo app('translator')->getFromJson('app.description'); ?> </th>
                                            <th><?php echo app('translator')->getFromJson('app.action'); ?> </th>
                                        </tr>
                                        <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td> <?php echo e($faq->title); ?>  </td>
                                                <td> <?php echo e($faq->description); ?>  </td>
                                                <td width="100">
                                                    <a href="<?php echo e(route('faq_update', [$faq->campaign_id,$faq->id])); ?>" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> </a>
                                                    <a href="javascript:;" class="btn btn-danger btn-xs" data-id="<?php echo e($faq->id); ?>"><i class="fa fa-trash"></i> </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </div>
                            </div>
                        <?php endif; ?>
    </div>   <!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>

    <script>
        $(document).ready(function() {
            $('.btn-danger').on('click', function (e) {
                if (!confirm("<?php echo app('translator')->getFromJson('app.are_you_sure_undone'); ?>")) {
                    e.preventDefault();
                    return false;
                }

                var selector = $(this);
                var data_id = $(this).data('id');

                $.ajax({
                    type: 'POST',
                    url: '<?php echo e(route('delete_faq')); ?>',
                    data: {data_id: data_id, _token: '<?php echo e(csrf_token()); ?>'},
                    success: function (data) {
                        if (data.success == 1) {
                            selector.closest('tr').hide('slow');
                        }
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>