<div class="single-campaign-header">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="single-campaign-title"><?php echo e($campaign->title); ?></h1>
            </div>
        </div>
    </div>

    <div class="single-campaign-menu">

        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <?php 
                    $backers_count = $campaign->success_payments->count();
                    $updates_count = $campaign->updates->count();
                    $faqs_count = $campaign->faqs->count();
                     ?>
                    <ul>
                        <li><a href="<?php echo e(route('campaign_single', [$campaign->id, $campaign->slug])); ?>"> <?php echo app('translator')->getFromJson('app.campaign_home'); ?> </a> </li>

                        <li><a href="<?php echo e(route('campaign_backers', [$campaign->id, $campaign->slug])); ?>"> <?php echo app('translator')->getFromJson('app.backers'); ?> (<?php echo e($backers_count); ?>) </a> </li>
                        <li>
                            <a href="<?php echo e(route('campaign_updates', [$campaign->id, $campaign->slug])); ?>"> <?php echo app('translator')->getFromJson('app.updates'); ?>
                                <?php if($updates_count > 0): ?> (<?php echo e($updates_count); ?>) <?php endif; ?>
                            </a> </li>
                        <li>
                            <a href="<?php echo e(route('campaign_faqs', [$campaign->id, $campaign->slug])); ?>"> <?php echo app('translator')->getFromJson('app.faqs'); ?>  <?php if($faqs_count > 0): ?> (<?php echo e($faqs_count); ?>) <?php endif; ?> </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>