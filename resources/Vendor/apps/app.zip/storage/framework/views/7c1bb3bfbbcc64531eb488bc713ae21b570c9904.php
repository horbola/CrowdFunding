<?php 
$auth_user = \Illuminate\Support\Facades\Auth::user();
 ?>
<style type="text/css">
    .navbar-inverse .navbar-brand, .navbar-inverse .navbar-nav>li>a {
        color: #ffffff;
    }
    .navbar-inverse {
        background-color: #42ccae;
        border: none;
    }
    .navbar-inverse ul li a:hover {
        background-color: #42ccae;
        border: none;
    }
    .navbar-top-links li a{color: #052d24}
    
</style>
<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation" style="background-color: #42ccae; color: #ffffff; border: none;">
    <div class="navbar-header">
        <a class="navbar-brand" href="<?php echo e(route('dashboard')); ?>">
            <?php echo e(get_option('site_name')); ?>

        </a>
    </div>
    <button class="navbar-toggle" data-target=".navbar-collapse" data-toggle="collapse" type="button">
        <span class="sr-only">
            Toggle navigation
        </span>
        <span class="icon-bar">
        </span>
        <span class="icon-bar">
        </span>
        <span class="icon-bar">
        </span>
    </button>
    <ul class="nav navbar-nav navbar-left navbar-top-links">
        <li>
            <a href="<?php echo e(route('home')); ?>" target="_blank">
                <i class="fa fa-home fa-fw">
                </i>
                Go To HomePage
            </a>
        </li>
    </ul>
    <ul class="nav navbar-right navbar-top-links">
        <li class="dropdown navbar-inverse">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                <i class="fa fa-bell fa-fw">
                </i>
                <b class="caret">
                </b>
            </a>
            <ul class="dropdown-menu dropdown-alerts">
                <li>
                    <a href="#">
                        <div>
                            <i class="fa fa-comment fa-fw">
                            </i>
                            New Comment
                            <span class="pull-right text-muted small">
                                4 minutes ago
                            </span>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <div>
                            <i class="fa fa-twitter fa-fw">
                            </i>
                            3 New Followers
                            <span class="pull-right text-muted small">
                                12 minutes ago
                            </span>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <div>
                            <i class="fa fa-envelope fa-fw">
                            </i>
                            Message Sent
                            <span class="pull-right text-muted small">
                                4 minutes ago
                            </span>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <div>
                            <i class="fa fa-tasks fa-fw">
                            </i>
                            New Task
                            <span class="pull-right text-muted small">
                                4 minutes ago
                            </span>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <div>
                            <i class="fa fa-upload fa-fw">
                            </i>
                            Server Rebooted
                            <span class="pull-right text-muted small">
                                4 minutes ago
                            </span>
                        </div>
                    </a>
                </li>
                <li class="divider">
                </li>
                <li>
                    <a class="text-center" href="#">
                        <strong>
                            See All Alerts
                        </strong>
                        <i class="fa fa-angle-right">
                        </i>
                    </a>
                </li>
            </ul>
        </li>
        <li class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                <i class="fa fa-user fa-fw">
                </i>
                </i> <?php echo e(Auth::user()->name); ?>

                <b class="caret">
                </b>
            </a>
            <ul class="dropdown-menu dropdown-user">
                <li>
                    <a href="<?php echo e(route('profile')); ?>">
                        <i class="fa fa-user fa-fw">
                        </i>
                        User Profile
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('change_password')); ?>">
                        <i class="fa fa-gear fa-fw">
                        </i>
                        Settings
                    </a>
                </li>
                <li class="divider">
                </li>
                <li>
                    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <i class="fa fa-sign-out"></i> <?php echo app('translator')->getFromJson('app.logout'); ?>
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo e(csrf_field()); ?>

                    </form>
                </li>
            </ul>
        </li>
    </ul>
    <!-- /.navbar-top-links -->
    <div class="navbar-default sidebar" role="navigation">
        <div class="sidebar-nav navbar-collapse">
            <ul class="nav" id="side-menu">
                <li class="sidebar-search">
                    <form action="<?php echo e(route('search')); ?>" class="input-group custom-search-form" method="get">
                        <input class="form-control" placeholder="Search..." name="q" type="text">
                            <span class="input-group-btn">
                            <button type="submit" class="btn btn-default"><i class="fa fa-search"></i> </button>
                            </span>
                        </input>
                    </form>
                    <!-- /input-group -->
                </li>
                <li>
                    <a <?php echo e(Request::is('dashboard/controlpanel') ? "active": ""); ?> href="<?php echo e(route('dashboard')); ?>">
                        <i class="fa fa-dashboard fa-fw">
                        </i>
                        Dashboard
                    </a>
                </li>
                <li>
                <a href="#"><i class="fa fa-bullhorn"></i> <?php echo app('translator')->getFromJson('app.my_campaigns'); ?><span class="fa arrow"></span></a>
                <ul class="nav nav-second-level">
                    <li>  <a href="<?php echo e(route('my_campaigns')); ?>"><?php echo app('translator')->getFromJson('app.my_campaigns'); ?></a> </li>
                    <li>  <a href="<?php echo e(route('start_campaign')); ?>"><?php echo app('translator')->getFromJson('app.start_a_campaign'); ?></a> </li>
                    <li>  <a href="<?php echo e(route('my_pending_campaigns')); ?>"><?php echo app('translator')->getFromJson('app.pending_campaigns'); ?></a> </li>
                </ul>
            </li>

            <?php if($auth_user->is_admin()): ?>
            <li> <a href="<?php echo e(route('categories')); ?>"><i class="fa fa-folder-o"></i> <?php echo app('translator')->getFromJson('app.categories'); ?></a>  </li>
            <li>
                <a href="#"><i class="fa fa-bullhorn"></i> <?php echo app('translator')->getFromJson('app.campaigns'); ?><span class="fa arrow"></span></a>
                <ul class="nav nav-second-level">
                    <li> <a href="<?php echo e(route('all_campaigns')); ?>"><?php echo app('translator')->getFromJson('app.all_campaigns'); ?></a> </li>
                    <li> <a href="<?php echo e(route('staff_picks')); ?>"><?php echo app('translator')->getFromJson('app.staff_picks'); ?></a> </li>
                    <li> <a href="<?php echo e(route('funded')); ?>"><?php echo app('translator')->getFromJson('app.funded'); ?></a> </li>
                    <li> <a href="<?php echo e(route('blocked_campaigns')); ?>"><?php echo app('translator')->getFromJson('app.blocked_campaigns'); ?></a> </li>
                    <li> <a href="<?php echo e(route('pending_campaigns')); ?>"><?php echo app('translator')->getFromJson('app.pending_campaigns'); ?></a> </li>
                    <li> <a href="<?php echo e(route('expired_campaigns')); ?>"><?php echo app('translator')->getFromJson('app.expired_campaigns'); ?></a> </li>
                    <li> <a href="<?php echo e(route('comment')); ?>">Comments</a> </li>
                </ul>
                <!-- /.nav-second-level -->
            </li>

            <li>
                <a href="#"><i class="fa fa-wrench fa-fw"></i> <?php echo app('translator')->getFromJson('app.settings'); ?><span class="fa arrow"></span></a>
                <ul class="nav nav-second-level">
                    <li> <a href="<?php echo e(route('general_settings')); ?>"><?php echo app('translator')->getFromJson('app.general_settings'); ?></a> </li>
                    <li> <a href="<?php echo e(route('payment_settings')); ?>"><?php echo app('translator')->getFromJson('app.payment_settings'); ?></a> </li>
                    <li> <a href="<?php echo e(route('theme_settings')); ?>"><?php echo app('translator')->getFromJson('app.theme_settings'); ?></a> </li>
                    <li> <a href="<?php echo e(route('social_settings')); ?>"><?php echo app('translator')->getFromJson('app.social_settings'); ?></a> </li>
                    <li> <a href="<?php echo e(route('other_settings')); ?>"><?php echo app('translator')->getFromJson('app.other_settings'); ?></a> </li>
                </ul>
                <!-- /.nav-second-level -->
            </li>
            <li> <a href="<?php echo e(route('pages')); ?>"><i class="fa fa-file-word-o"></i> <?php echo app('translator')->getFromJson('app.pages'); ?></a>  </li>
            <?php endif; ?>

            <li> <a href="<?php echo e(route('payments')); ?>"><i class="fa fa-money"></i> <?php echo app('translator')->getFromJson('app.payments'); ?></a>  </li>
            <li> <a href="<?php echo e(route('withdraw')); ?>"><i class="fa fa-credit-card"></i> <?php echo app('translator')->getFromJson('app.withdraw'); ?></a>  </li>
            <li> <a href="<?php echo e(route('profile')); ?>"><i class="fa fa-user"></i> <?php echo app('translator')->getFromJson('app.profile'); ?></a>  </li>
            <li> <a href="<?php echo e(route('change_password')); ?>"><i class="fa fa-lock"></i> <?php echo app('translator')->getFromJson('app.change_password'); ?></a>  </li>
            </ul>
        </div>
    </div>
</nav>