<?php $__env->startSection('title'); ?> <?php if(! empty($title)): ?> <?php echo e($title); ?> <?php endif; ?> - ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8## <?php $__env->stopSection(); ?>

<?php 
$auth_user = \Illuminate\Support\Facades\Auth::user();
 ?>

<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
     <?php if(!empty($title)): ?>
     <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header"> <?php echo e($title); ?></h1>
        </div>
        <!-- /.col-lg-12 -->
        <!-- /.row -->
    <?php endif; ?>
    <?php if($auth_user->is_admin()): ?>
    <div class="row">
        <div class="col-lg-3 col-md-6">
            <div class="panel panel-red">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-money fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php echo e($pending_campaign_count); ?></div>
                                        <div>Pending Campaigns</div>
                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo e(route('pending_campaigns')); ?>">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>

                                    <div class="clearfix"></div>
                                </div>
                            </a>
            </div>
        </div>
        <div class="col-lg-3 col-md-6">
                        <div class="panel panel-green">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-money fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php echo e($active_campaign_count); ?></div>
                                        <div>Active campaigns</div>
                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo e(route('all_campaigns')); ?>">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>

                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
        </div>
        <div class="col-lg-3 col-md-6">
            <div class="panel panel-red">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-money fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php echo e($blocked_campaign_count); ?></div>
                                        <div>Block Campaigns</div>
                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo e(route('blocked_campaigns')); ?>">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>

                                    <div class="clearfix"></div>
                                </div>
                            </a>
            </div>
        </div>
        <div class="col-lg-3 col-md-6">
                        <div class="panel panel-green">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-money fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php echo e($payment_created); ?></div>
                                        <div>Payment Created</div>
                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo e(route('payments')); ?>">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>

                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-3 col-md-6">
            <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-comments fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php echo e($comment_all); ?></div>
                                        <div>All Comments!</div>
                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo e(route('comment')); ?>">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>

                                    <div class="clearfix"></div>
                                </div>
                            </a>
            </div>
        </div>
        <div class="col-lg-3 col-md-6">
            <div class="panel panel-green">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-user fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php echo e($user_count); ?></div>
                                        <div>All Users</div>
                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo e(route('all-users')); ?>">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>

                                    <div class="clearfix"></div>
                                </div>
                            </a>
            </div>
        </div>
        <div class="col-lg-3 col-md-6">
                        <div class="panel panel-green">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-money fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php 
                                                    $campaign_owner_comission = get_option('campaign_owner_commission');
                                                     ?>
                                                    <?php echo e(get_option('campaign_owner_commission')); ?>%</div>
                                        <div>Owner Recevied</div>
                                    </div>
                                </div>
                            </div>
                            <a href="#">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>

                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
        </div>
        <div class="col-lg-3 col-md-6">
                        <div class="panel panel-green">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-money fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php echo e(100 - $campaign_owner_comission); ?>%</div>
                                        <div>Platform Recevied</div>
                                    </div>
                                </div>
                            </div>
                            <a href="#">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>

                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-4 col-md-6">
            <div class="panel panel-green">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-12 text-center">
                                        <div class="huge"><?php echo e(get_amount($payment_amount)); ?></div>
                                        <div>Total Amount</div>
                                    </div>
                                </div>
                            </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6">
            <div class="panel panel-green">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-12 text-center">
                                        <div class="huge"><?php 
                                                    $platform_owner_commission = ( (100 - $campaign_owner_comission) * $payment_amount ) / 100;
                                                     ?>

                                                    <?php echo e(get_amount($platform_owner_commission)); ?></div>
                                        <div>Platform Commission</div>
                                    </div>
                                </div>
                            </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6">
                        <div class="panel panel-green">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-12 text-center">
                                        <div class="huge"><?php echo e(get_amount($payment_amount - $platform_owner_commission)); ?></div>
                                        <div>Owner Commission</div>
                                    </div>
                                </div>
                            </div>
                        </div>
        </div>
    </div>
    <?php endif; ?>
    <!-- /.row -->
    <div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <?php echo app('translator')->getFromJson('app.last_pending_campaigns'); ?>
            </div>
            <div class="panel-body">
                <div class="row col-md-lg-12">
                    <?php if($pending_campaigns->count() > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover table-striped">
                            <tr>
                                <th><?php echo app('translator')->getFromJson('app.title'); ?></th>
                                <th><?php echo app('translator')->getFromJson('app.by'); ?></th>
                            </tr>

                            <?php $__currentLoopData = $pending_campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($pc->title); ?></td>
                                <td><?php echo e($pc->user->name); ?> <br /> <?php echo e($pc->user->email); ?> </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <!-- /.panel -->
    </div>
    </div>
    <!-- /.row -->
    <div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
               <?php echo app('translator')->getFromJson('app.last_ten_payment'); ?>
            </div>
            <div class="panel-body">
                <div class="row col-md-lg-12">
                    <div class="table-responsive">
                        <?php if($last_payments->count() > 0): ?>
                                        <table class="table table-striped table-bordered">

                                            <tr>
                                                <th><?php echo app('translator')->getFromJson('app.campaign_title'); ?></th>
                                                <th><?php echo app('translator')->getFromJson('app.payer_email'); ?></th>
                                                <th><?php echo app('translator')->getFromJson('app.amount'); ?></th>
                                                <th><?php echo app('translator')->getFromJson('app.time'); ?></th>
                                                <th>Reward</th>
                                                <th>View</th>
                                            </tr>

                                            <?php $__currentLoopData = $last_payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <tr>
                                                    <td><a href="<?php echo e(route('payment_view', $payment->id)); ?>"><?php echo e($payment->campaign['title']); ?></a></td>
                                                    <td><a href="<?php echo e(route('payment_view', $payment->id)); ?>"> <?php echo e($payment->email); ?> </a></td>
                                                    <td><?php echo e(get_amount($payment->amount)); ?></td>
                                                    <td><span data-toggle="tooltip" title="<?php echo e($payment->created_at->format('F d, Y h:i a')); ?>"><?php echo e($payment->created_at->format('F d, Y')); ?></span></td>

                                                    <td>
                                                        <?php if($payment->reward): ?>
                                                            <a href="<?php echo e(route('payment_view', $payment->id)); ?>" data-toggle="tooltip" title="<?php echo app('translator')->getFromJson('app.selected_reward'); ?>">
                                                                <i class="fa fa-gift"></i>
                                                            </a>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td><a href="<?php echo e(route('payment_view', $payment->id)); ?>"><i class="fa fa-eye"></i> </a></td>

                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </table>

                                    <?php else: ?>
                                        <?php echo app('translator')->getFromJson('app.no_campaigns_to_display'); ?>
                                    <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.panel -->
    </div>
    </div>
    <!-- /.row -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>