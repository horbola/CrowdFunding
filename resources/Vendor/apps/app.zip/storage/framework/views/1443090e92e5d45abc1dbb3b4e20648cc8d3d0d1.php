<?php $__env->startSection('title'); ?> <?php if(! empty($title)): ?> <?php echo e($title); ?> <?php endif; ?> - ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8## <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="page-wrapper">
        <div class="col-md-12">

                    <?php if( ! empty($title)): ?>
                        <div class="row">
                            <div class="col-lg-12">
                                <h1 class="page-header"> <?php echo e($title); ?>  </h1>
                            </div> <!-- /.col-lg-12 -->
                        </div> <!-- /.row -->
                    <?php endif; ?>

                    <?php echo $__env->make('admin.flash_msg', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


                       <div class="admin-campaign-lists">

                           <div class="row">
                               <div class="col-md-5">
                                   <?php echo app('translator')->getFromJson('app.total'); ?> : <?php echo e($campaigns->count()); ?>

                               </div>

                               <div class="col-md-7">

                                   <form class="form-inline" method="get" action="<?php echo e(route('campaign_admin_search')); ?>">
                                       <div class="form-group">
                                           <input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="<?php echo app('translator')->getFromJson('app.campaign_title_keyword'); ?>">
                                       </div>
                                       <button type="submit" class="btn btn-default"><?php echo app('translator')->getFromJson('app.search'); ?></button>
                                   </form>

                               </div>
                           </div>

                       </div>

                    <?php if($campaigns->count() > 0): ?>
                        <table class="table table-striped table-bordered">

                            <tr>
                                <th><?php echo app('translator')->getFromJson('app.image'); ?></th>
                                <th><?php echo app('translator')->getFromJson('app.title'); ?></th>
                                <th><?php echo app('translator')->getFromJson('app.campaign_info'); ?></th>
                                <th><?php echo app('translator')->getFromJson('app.owner_info'); ?></th>
                                <th><?php echo app('translator')->getFromJson('app.status'); ?></th>
                                <th><?php echo app('translator')->getFromJson('app.actions'); ?></th>
                            </tr>

                            <?php $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>

                                    <td width="70"><img src="<?php echo e($campaign->feature_img_url()); ?>" class="img-responsive" /></td>
                                    <td><?php echo e($campaign->title); ?>


                                        <?php if($campaign->is_funded == 1): ?>
                                            <p class="bg-success"><?php echo app('translator')->getFromJson('app.added_to_funded'); ?></p>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo app('translator')->getFromJson('app.goal'); ?> : <?php echo e(get_amount($campaign->goal)); ?> <br />
                                        <?php echo app('translator')->getFromJson('app.raised'); ?> :  <?php echo e(get_amount($campaign->success_payments->sum('amount'))); ?> <br />
                                        <?php echo app('translator')->getFromJson('app.raised_percent'); ?> : <?php echo e($campaign->percent_raised()); ?>%<br />
                                        <?php echo app('translator')->getFromJson('app.days_left'); ?> : <?php echo e($campaign->days_left()); ?><br />
                                        <?php echo app('translator')->getFromJson('app.backers'); ?> : <?php echo e($campaign->success_payments->count()); ?><br />
                                    </td>


                                    <td>
                                        <strong><?php echo e($campaign->user->name); ?></strong> <br />
                                        <?php echo app('translator')->getFromJson('app.address'); ?> : <?php echo e($campaign->address); ?>

                                    </td>
                                    <td>
                                        <?php 
                                            if($campaign->status == 1)echo "Active";
                                            else echo"Inactive";
                                                    
                                        ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('campaign_single', [$campaign->id, $campaign->slug])); ?>" class="btn btn-default btn-sm" data-toggle="tooltip" title="View"><i class="fa fa-eye"></i> </a>
                                    <a href="<?php echo e(route('edit', $campaign->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-pencil"></i> </a>
                                    <?php if($campaign->status == 0): ?>
                                            <a href="<?php echo e(route('campaign_status', [$campaign->id, 'approve'])); ?>" class="btn btn-success btn-sm" data-toggle="tooltip" title="<?php echo app('translator')->getFromJson('app.approve'); ?>"><i class="fa fa-check-circle-o"></i> </a>
                                            <a href="<?php echo e(route('campaign_status', [$campaign->id, 'block'])); ?>" class="btn btn-danger btn-sm" data-toggle="tooltip" title="<?php echo app('translator')->getFromJson('app.block'); ?>"><i class="fa fa-ban"></i> </a>


                                        <?php elseif($campaign->status == 1): ?>

                                            <a href="<?php echo e(route('campaign_status', [$campaign->id, 'block'])); ?>" class="btn btn-danger btn-sm" data-toggle="tooltip" title="<?php echo app('translator')->getFromJson('app.block'); ?>"><i class="fa fa-ban"></i> </a>

                                        <?php elseif($campaign->status == 2): ?>
                                            <a href="<?php echo e(route('campaign_status', [$campaign->id, 'approve'])); ?>" class="btn btn-success btn-sm" data-toggle="tooltip" title="<?php echo app('translator')->getFromJson('app.approve'); ?>"><i class="fa fa-check-circle-o"></i> </a>
                                        <?php endif; ?>

                                        <?php if(request()->segment(3) == 'expired_campaigns'): ?>
                                            <?php if($campaign->is_funded != 1): ?>
                                                <a href="<?php echo e(route('campaign_status', [$campaign->id, 'funded'])); ?>" class="btn btn-info btn-sm" data-toggle="tooltip" title="<?php echo app('translator')->getFromJson('app.mark_as_funded'); ?>"><i class="fa fa-check-circle-o"></i>  <?php echo app('translator')->getFromJson('app.mark_as_funded'); ?></a>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                        <?php if($campaign->is_staff_picks != 1): ?>
                                            <a href="<?php echo e(route('campaign_status', [$campaign->id, 'add_staff_picks'])); ?>" class="btn btn-info btn-sm" data-toggle="tooltip" title="<?php echo app('translator')->getFromJson('app.add_staff_picks'); ?>"><i class="fa fa-plus-square-o"></i>  <?php echo app('translator')->getFromJson('app.add_staff_picks'); ?></a>

                                        <?php else: ?>
                                            <a href="<?php echo e(route('campaign_status', [$campaign->id, 'remove_staff_picks'])); ?>" class="btn btn-warning btn-sm" data-toggle="tooltip" title="<?php echo app('translator')->getFromJson('app.remove_staff_picks'); ?>"><i class="fa fa-minus-square-o"></i>  <?php echo app('translator')->getFromJson('app.remove_staff_picks'); ?></a>

                                        <?php endif; ?>

                                    </td>

                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </table>

                        <?php echo $campaigns->links(); ?>


                    <?php else: ?>

                        <?php echo app('translator')->getFromJson('app.no_campaigns_to_display'); ?>

                    <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>