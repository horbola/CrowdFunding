<?php $__env->startSection('title'); ?> <?php if( ! empty($title)): ?> <?php echo e($title); ?> | <?php endif; ?> ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8## <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section class="checkout-empty">


        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">


                    <div class="checkout-wrap">
                        <h1><i class="fa fa-exclamation-triangle"></i> <?php echo app('translator')->getFromJson('app.nothing_in_the_checkout'); ?></h1>
                        <a href="<?php echo e(route('browse_categories')); ?>" class="btn btn-lg-filled"><?php echo app('translator')->getFromJson('app.browse_campaign'); ?></a>
                    </div>


                </div>

            </div>
        </div>


    </section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>

    <script>
        $(function(){
            $(document).on('click', '.donate-amount-placeholder ul li', function(e){
                $(this).closest('form').find($('[name="amount"]')).val($(this).data('value'));
            });
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.charity.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>