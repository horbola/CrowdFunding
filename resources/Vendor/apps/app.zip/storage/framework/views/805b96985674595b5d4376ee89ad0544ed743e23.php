<?php $__env->startSection('title'); ?> <?php if(! empty($title)): ?> <?php echo e($title); ?> <?php endif; ?> - ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8## <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <?php if( ! empty($title)): ?>
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header"> <?php echo e($title); ?>  </h1>
        </div> <!-- /.col-lg-12 -->
    </div> <!-- /.row -->
    <?php endif; ?>
    <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                               Comments Table
                            </div>
                            <!-- /.panel-heading -->
                            <div class="panel-body">
                                <div class="dataTable_wrapper">
                                    <table class="table table-striped table-bordered table-hover" id="commentTable">
                                        <thead>
                                            <tr>
                                                <th>SL No</th>
                                                <th class="col-md-2">User Name</th>
                                                <th class="col-md-3">Comment</th>
                                                <th class="col-md-3">Comment Campaign</th>
                                                <th class="col-md-1">Submited</th>
                                                <th class="col-md-1">Status</th>
                                                <th class="col-md-2">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php  $sl = 1;  ?>
                                            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="odd gradeX">
                                                <td><?php echo e($sl); ?> <?php  $sl++  ?></td>
                                                <td><?php echo e($comment->user->name); ?></td>
                                                <td><?php echo e($comment->comment); ?></td>
                                                <td><a target="_blank" href="<?php echo e(route('campaign_single', [$comment->campaign->id, $comment->campaign->slug])); ?>"><?php echo e($comment->campaign->title); ?></a></td>
                                                <td><?php echo e($comment->created_at); ?></td>
                                                <td id="status<?php echo e($comment->id); ?>"><?php echo e(($comment->approved === 1)?'Active':'Inactive'); ?></td>
                                                <td><a href="javascript:void(0)" class="btn btn-success btn-sm" onclick="CommentActive('<?php echo e($comment->id); ?>')" title="Active"><i class="fa fa-check"></i></a> <a href="javascript:void(0)" onclick="CommentDelete('<?php echo e($comment->id); ?>')" class="btn btn-danger btn-sm" title="Delete"><i class="fa fa-ban"></i></a></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <!-- /.table-responsive -->
                            </div>
                            <!-- /.panel-body -->
                        </div>
                        <!-- /.panel -->
                    </div>
                    <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-js'); ?>
<!-- DataTables JavaScript -->
<script src="<?php echo e(asset('admin/js/dataTables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/dataTables/dataTables.bootstrap.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
        $('#commentTable').DataTable({
            responsive: true
        });
    });
    function CommentActive(id){
        $.ajax({
            type: "POST",
            url: '<?php echo e(route('comment')); ?>',
            data: {'id': id, "_token": "<?php echo e(csrf_token()); ?>", 'status':'1', 'message':'Active'},
            success: function(msg) {
                var data = $.parseJSON(msg);
                toastr.info(data.message);
                $('#status'+id).text('Active');
            }
        });

    }
    function CommentDelete(id){
        $.ajax({
            type: "POST",
            url: '<?php echo e(route('comment')); ?>',
            data: {'id': id, "_token": "<?php echo e(csrf_token()); ?>", 'status':'0', 'message':'Inactive'},
            success: function(msg) {
                var data = $.parseJSON(msg);
                toastr.warning(data.message);
                $('#status'+id).text('Inactive');
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>