<?php $__env->startSection('title'); ?> <?php if( ! empty($title)): ?> <?php echo e($title); ?> | <?php endif; ?> ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8## <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section class="categories-wrap"> <!-- explore categories -->
        <div class="container">

            <div class="row">
                <div class="col-md-12">
                    <h2 class="section-title"> <?php echo e($page->title); ?> </h2>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <?php echo $page->post_content; ?>

                </div>
            </div>

        </div>
    </section> <!-- #explore categories -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.charity.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>