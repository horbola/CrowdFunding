<?php $__env->startSection('title'); ?> <?php if(! empty($title)): ?> <?php echo e($title); ?> <?php endif; ?> - ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8## <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="page-wrapper">
        <div class="col-md-12">

                    <?php if( ! empty($title)): ?>
                        <div class="row">
                            <div class="col-lg-12">
                                <h1 class="page-header"> <?php echo e($title); ?>  </h1>
                            </div> <!-- /.col-lg-12 -->
                        </div> <!-- /.row -->
                    <?php endif; ?>

                    <?php echo $__env->make('admin.flash_msg', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


                    <div class="admin-campaign-lists">

                        <div class="row">
                            <div class="col-md-5">
                                <?php echo app('translator')->getFromJson('app.total'); ?> : <?php echo e($payments->count()); ?>

                            </div>

                            <div class="col-md-7">

                                <form class="form-inline" method="get" action="">
                                    <div class="form-group">
                                        <input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="<?php echo app('translator')->getFromJson('app.payer_email'); ?>">
                                    </div>
                                    <button type="submit" class="btn btn-default"><?php echo app('translator')->getFromJson('app.search'); ?></button>
                                </form>

                            </div>
                        </div>

                    </div>

                    <?php if($payments->count() > 0): ?>
                        <table class="table table-striped table-bordered">

                            <tr>
                                <th><?php echo app('translator')->getFromJson('app.campaign_title'); ?></th>
                                <th><?php echo app('translator')->getFromJson('app.payer_email'); ?></th>
                                <th><?php echo app('translator')->getFromJson('app.amount'); ?></th>
                                <th><?php echo app('translator')->getFromJson('app.method'); ?></th>
                                <th><?php echo app('translator')->getFromJson('app.time'); ?></th>
                                <th>Reward</th>
                                <th>View</th>
                            </tr>

                            <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td><a href="<?php echo e(route('payment_view', $payment->id)); ?>"><?php echo e($payment->campaign->title); ?></a></td>
                                    <td><a href="<?php echo e(route('payment_view', $payment->id)); ?>"> <?php echo e($payment->email); ?> </a></td>
                                    <td><?php echo e(get_amount($payment->amount)); ?></td>
                                    <td><?php echo e($payment->payment_method); ?></td>
                                    <td><span data-toggle="tooltip" title="<?php echo e($payment->created_at->format('F d, Y h:i a')); ?>"><?php echo e($payment->created_at->format('F d, Y')); ?></span></td>

                                    <td>
                                        <?php if($payment->reward): ?>
                                            <a href="<?php echo e(route('payment_view', $payment->id)); ?>" data-toggle="tooltip" title="<?php echo app('translator')->getFromJson('app.selected_reward'); ?>">
                                                <i class="fa fa-gift"></i>
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                    <td><a href="<?php echo e(route('payment_view', $payment->id)); ?>"><i class="fa fa-eye"></i> </a></td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </table>

                        <?php echo $payments->links(); ?>


                    <?php else: ?>
                        <?php echo app('translator')->getFromJson('app.no_data'); ?>
                    <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>