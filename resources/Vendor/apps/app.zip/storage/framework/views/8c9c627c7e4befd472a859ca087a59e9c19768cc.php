<?php $__env->startSection('title'); ?> <?php if( ! empty($title)): ?> <?php echo e($title); ?> | <?php endif; ?> ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8## <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="campaign-details-wrap">

        <div class="container">

            <div class="row">
                <div class="col-md-8 col-md-offset-2">

                    <div class="checkout-wrap">

                        <div class="payment-received">
                            <h1> <i class="fa fa-check-circle-o"></i> <?php echo app('translator')->getFromJson('app.payment_thank_you'); ?></h1>
                            <p><?php echo app('translator')->getFromJson('app.payment_receive_successfully'); ?></p>
                            <a href="/" class="btn btn-filled"><?php echo app('translator')->getFromJson('app.home'); ?></a>
                        </div>

                    </div>

                </div>



            </div>


        </div>

    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.charity.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>