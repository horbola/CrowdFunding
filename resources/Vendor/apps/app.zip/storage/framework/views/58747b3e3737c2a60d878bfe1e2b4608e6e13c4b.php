<?php $__env->startSection('title'); ?> <?php if(! empty($title)): ?> <?php echo e($title); ?> <?php endif; ?> - ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8## <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
	<?php if( ! empty($title)): ?>
    <div class="row">
        <div class="col-lg-12 col-sm-12">
            <h1 class="page-header"> <?php echo e($title); ?>  </h1>
        </div> <!-- /.col-lg-12 -->
    </div> <!-- /.row -->
    <?php endif; ?>
    <?php echo $__env->make('admin.flash_msg', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                               Users Table
                            </div>
                            <!-- /.panel-heading -->
                            <div class="panel-body">
                                <div class="dataTable_wrapper">
                                    <table class="table table-striped table-bordered table-hover" id="usersTable">
                                        <thead>
                                            <tr>
                                                <th>SL No</th>
                                                <th>User Name</th>
                                                <th>Date of Birth</th>
                                                <th>NID</th>
                                                <th>Mobile</th>
                                                <th>Email</th>
                                                <th>Address</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        	<?php  $sl = 1;  ?>
                                        	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="odd gradeX">
                                                <td><?php echo e($sl); ?> <?php  $sl++  ?></td>
                                                <td><?php echo e($user->name); ?></td>
                                                <td><?php echo e($user->dob); ?></td>
                                                <td><?php echo e($user->nid); ?></td>
                                                <td><?php echo e($user->phone); ?></td>
                                                <td><?php echo e($user->email); ?></td>
                                                <td><?php echo e($user->address); ?></td>
                                                <td><?php echo e(($user->active_status == 1)?'Active':'Inactive'); ?></td>
                                                <td><a class="btn btn-success  btn-sm" href="<?php echo e(route('user_show', $user->id)); ?>"><i class="fa fa-pencil"></i></a></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <!-- /.table-responsive -->
                            </div>
                            <!-- /.panel-body -->
                        </div>
                        <!-- /.panel -->
                    </div>
                    <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-js'); ?>
<!-- DataTables JavaScript -->
<script src="<?php echo e(asset('admin/js/dataTables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/dataTables/dataTables.bootstrap.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
        $('#usersTable').DataTable({
            responsive: true
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>