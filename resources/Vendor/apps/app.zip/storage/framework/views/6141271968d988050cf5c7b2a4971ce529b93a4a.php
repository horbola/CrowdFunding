<?php $__env->startSection('title'); ?> <?php if( ! empty($title)): ?> <?php echo e($title); ?> | <?php endif; ?> ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8## <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section class="campaign-details-wrap">

        <?php echo $__env->make('single_campaign_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="container">
            <div class="row">
                <div class="col-md-8">

                    <div class="campaign-decription">

                        <?php 
                        $backers = $campaign->success_payments()->orderBy('id','desc')->paginate(20);
                         ?>


                        <?php if($backers->count()): ?>
                            <table class="table table-bordered table-striped">
                                <tr>
                                    <th><?php echo app('translator')->getFromJson('app.backer_name'); ?></th>
                                    <th><?php echo app('translator')->getFromJson('app.amount'); ?></th>
                                </tr>

                                <?php if($backers->count() > 0): ?>
                                    <?php $__currentLoopData = $backers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $backer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <td><?php echo e($backer->contributor_name_display =='anonymous' ? trans('app.anonymous') : $backer->name); ?></td>
                                            <td><?php echo e(get_amount($backer->amount)); ?></td>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </table>

                            <?php echo e($backers->links()); ?>

                        <?php else: ?>

                            <div class="no-data">
                                <i class="fa fa-smile-o"></i> <h1><?php echo app('translator')->getFromJson('app.no_contribute'); ?></h1>
                            </div>

                        <?php endif; ?>


                    </div>

                </div>

                <div class="col-md-4">
                    <?php echo $__env->make('campaign_single_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>

            </div>
        </div>


    </section>


    <?php echo $__env->make('footer_get_start_section', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>

    <script>
        $(function(){
            $(document).on('click', '.donate-amount-placeholder ul li', function(e){
                $(this).closest('form').find($('[name="amount"]')).val($(this).data('value'));
            });
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.charity.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>