<?php $__env->startSection('title'); ?> <?php if( ! empty($title)): ?> <?php echo e($title); ?> | <?php endif; ?> ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8## <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="campaign-details-wrap">
        <?php echo $__env->make('single_campaign_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="container">

            <div class="row">
                <div class="col-md-8 col-md-offset-2">

                    <div class="checkout-wrap">

                        <div class="contributing-to">
                            <p class="contributing-to-name"><strong> <?php echo app('translator')->getFromJson('app.you_are_contributing_to'); ?> <?php echo e($campaign->user->name); ?></strong></p>
                            <h3><?php echo e($campaign->title); ?></h3>
                        </div>

                        <hr />

                        <div class="row">
                            <?php if(get_option('enable_stripe') == 1): ?>
                                <div class="col-md-4">
                                    <div class="stripe-button-container">
                                        <script
                                                src="https://checkout.stripe.com/checkout.js" class="stripe-button"
                                                data-key="<?php echo e(get_stripe_key()); ?>"
                                                data-amount="<?php echo e(session('cart.amount') * 100); ?>"
                                                data-email="<?php echo e(session('cart.email')); ?>"
                                                data-name="<?php echo e(get_option('site_name')); ?>"
                                                data-description="<?php echo e($campaign->title." Contributing"); ?>"
                                                data-currency="USD"
                                                data-image="<?php echo e(asset('assets/images/stripe_logo.jpg')); ?>"
                                                data-locale="auto">
                                        </script>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <?php if(get_option('enable_walletmix') == 1): ?>
                                <div class="col-md-4">
                                    <?php echo e(Form::open(['route' => 'payment_wallitmix_receive'])); ?>

                                    <input type="hidden" name="cmd" value="_xclick" />
                                    <input type="hidden" name="no_note" value="1" />
                                    <input type="hidden" name="lc" value="UK" />
                                    <input type="hidden" name="currency_code" value="<?php echo e(get_option('currency_sign')); ?>" />
                                    <input type="hidden" name="bn" value="PP-BuyNowBF:btn_buynow_LG.gif:NonHostedGuest" />
                                    <button type="submit" class="btn btn-info"> <i class="fa fa-money"></i> Walletmix</button>
                                    <?php echo e(Form::close()); ?>

                                </div>
                            <?php endif; ?>

                            <?php if(get_option('enable_paypal') == 1): ?>
                                <div class="col-md-4">
                                    <?php echo e(Form::open(['route' => 'payment_paypal_receive'])); ?>

                                    <input type="hidden" name="cmd" value="_xclick" />
                                    <input type="hidden" name="no_note" value="1" />
                                    <input type="hidden" name="lc" value="UK" />
                                    <input type="hidden" name="currency_code" value="<?php echo e(get_option('currency_sign')); ?>" />
                                    <input type="hidden" name="bn" value="PP-BuyNowBF:btn_buynow_LG.gif:NonHostedGuest" />
                                    <button type="submit" class="btn btn-info"> <i class="fa fa-paypal"></i> <?php echo app('translator')->getFromJson('app.pay_with_paypal'); ?></button>
                                    <?php echo e(Form::close()); ?>

                                </div>
                            <?php endif; ?>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>

    <script>
        $(function() {
            $('.stripe-button').on('token', function(e, token){
                $('#stripeForm').replaceWith('');

                $.ajax({
                    url : '<?php echo e(route('payment_stripe_receive')); ?>',
                    type: "POST",
                    data: { stripeToken : token.id, _token : '<?php echo e(csrf_token()); ?>' },
                    success : function (data) {
                        if (data.success == 1){
                            $('.checkout-wrap').html(data.response);
                            toastr.success(data.msg, '<?php echo app('translator')->getFromJson('app.success'); ?>', toastr_options);
                        }
                    }
                });
            });
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.charity.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>