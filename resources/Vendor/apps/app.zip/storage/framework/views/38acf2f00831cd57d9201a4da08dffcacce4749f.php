<div class="single-donate-wrap">

    <h3 class="campaign-single-sub-title"><?php echo e($campaign->short_description); ?></h3>

    <div class="single-author-box">
        <img src="<?php echo e($campaign->user->get_gravatar()); ?>">
        <p><strong><?php echo e($campaign->user->name); ?></strong> <br />   <?php echo e($campaign->address); ?> </p>
    </div>

    <?php if($campaign->get_category): ?>
        <div class="campaign-tag-list">
            <a href="#"><i class="glyphicon glyphicon-tag"></i> <?php echo e($campaign->get_category->category_name); ?> </a>
        </div>
    <?php endif; ?>

    <div class="campaign-progress-info">

        <h4><?php echo e(get_amount($campaign->success_payments->sum('amount'))); ?> <small><?php echo app('translator')->getFromJson('app.raised_of'); ?> <?php echo e(get_amount($campaign->goal)); ?> <?php echo app('translator')->getFromJson('app.goal'); ?></small></h4>

        <div class="progress">
            <?php 
            $percent_raised = $campaign->percent_raised();
             ?>
            <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo e($percent_raised); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($percent_raised <= 100 ? $percent_raised : 100); ?>%;">
                <?php echo e($percent_raised); ?>%
            </div>
        </div>

        <ul>
            <li><strong><?php echo e($campaign->days_left()); ?></strong> <?php echo app('translator')->getFromJson('app.days_left'); ?></li>
            <li><strong><?php echo e($campaign->success_payments->count()); ?></strong> <?php echo app('translator')->getFromJson('app.backers'); ?></li>
        </ul>

    </div>

    <hr />

    <div class="socialShareWrap">
        <ul>
            <li><a href="#" class="share s_facebook"><i class="fa fa-facebook-square"></i> </a> </li>
            <li><a href="#" class="share s_twitter"><i class="fa fa-twitter-square"></i> </a> </li>
            <li><a href="#" class="share s_plus"><i class="fa fa-google-plus-square"></i> </a> </li>
            <li><a href="#" class="share s_linkedin"><i class="fa fa-linkedin-square"></i> </a> </li>
            
            <li><a href="#" class="share s_pinterest"><i class="fa fa-pinterest-square"></i> </a> </li>
            <li><a href="#" class="share s_tumblr"><i class="fa fa-tumblr-square"></i> </a> </li>
            
        </ul>
    </div>

    <?php 
    $is_ended = $campaign->is_ended();
     ?>

    <div class="donate_form">

        <h2><?php echo app('translator')->getFromJson('app.donate'); ?></h2>
         <?php if( ! $is_ended): ?>
        
        <?php echo e(Form::open([ 'route' => 'add_to_cart', 'class' => 'form-horizontal'])); ?>

        <input type="hidden" name="campaign_id" value="<?php echo e($campaign->id); ?>" />
        <div class="donate_amount_field">
            <div class="donate_currency"><?php echo e(get_currency_symbol(get_option('currency_sign'))); ?></div>
            <input type="number" step="1" min="1" name="amount" class="form-control" value="<?php echo e($campaign->recommended_amount); ?>" placeholder="<?php echo app('translator')->getFromJson('app.enter_amount'); ?>" />
        </div>

        <?php if($campaign->amount_prefilled()): ?>
            <div class="donate-amount-placeholder">
                <ul>
                    <?php $__currentLoopData = $campaign->amount_prefilled(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amount_prefield): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li data-value="<?php echo e($amount_prefield); ?>"><?php echo e(get_amount($amount_prefield)); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="donate-form-button">
            <?php if($campaign->status == 1): ?>
            <button type="submit" class="btn btn-primary btn-block btn-lg"><?php echo app('translator')->getFromJson('app.donate'); ?></button>
            <?php else: ?>
            <a href="javascript:void(0)" class="btn btn-primary btn-block btn-lg"><?php echo app('translator')->getFromJson('app.donate'); ?></a>
            <?php endif; ?>
        </div>
        <?php echo e(Form::close()); ?>


        <?php else: ?>
        <div class="alert alert-warning">
            <h5><?php echo app('translator')->getFromJson('app.campaign_has_been_ended'); ?></h5>
        </div>
        <?php endif; ?>

    </div>


    <?php if($campaign->rewards->count() > 0): ?>
        <div class="rewards-wrap">

            <h2><?php echo app('translator')->getFromJson('app.or_choose_a_reward'); ?></h2>

            <?php $__currentLoopData = $campaign->rewards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php  $claimed_count = $reward->payments->count();  ?>

                <div class="reward-box <?php if($reward->quantity <= $claimed_count || $is_ended ): ?> reward-disable <?php endif; ?> ">
                    <?php if($reward->quantity > $claimed_count ): ?>
                        <a href="<?php echo e(route('add_to_cart', $reward->id)); ?>">
                            <span class="reward-amount"><?php echo app('translator')->getFromJson('app.pledge'); ?> <strong><?php echo e(get_amount($reward->amount)); ?></strong></span>
                            <span class="reward-text"><?php echo e($reward->description); ?></span>
                            <span class="reward-claimed-count"> <?php echo e($claimed_count); ?> <?php echo app('translator')->getFromJson('app.claimed_so_far'); ?> <?php echo e($reward->quantity); ?> </span>
                            <span class="reward-estimated-delivery"> <?php echo app('translator')->getFromJson('app.estimated_delivery'); ?>: <?php echo e(date('F Y', strtotime($reward->estimated_delivery))); ?></span>
                            <span class="reward-button"> <?php echo app('translator')->getFromJson('app.select_reward'); ?> </span>
                        </a>

                        <?php else: ?>
                            <span class="reward-amount"><?php echo app('translator')->getFromJson('app.pledge'); ?> <strong><?php echo e(get_amount($reward->amount)); ?></strong></span>
                            <span class="reward-text"><?php echo e($reward->description); ?></span>
                            <span class="reward-claimed-count"> <?php echo e($claimed_count); ?> <?php echo app('translator')->getFromJson('app.claimed_so_far'); ?> <?php echo e($reward->quantity); ?> </span>
                            <span class="reward-estimated-delivery"> <?php echo app('translator')->getFromJson('app.estimated_delivery'); ?>: <?php echo e(date('F Y', strtotime($reward->estimated_delivery))); ?></span>
                            <span class="reward-button"> <?php echo app('translator')->getFromJson('app.sold_out'); ?> </span>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    <?php endif; ?>

</div>