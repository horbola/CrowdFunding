
<footer>
    <div class="container footer-top">

        <div class="row">

            <div class="col-md-3">
                <div class="footer-about">
                    <?php if(logo_url()): ?>
                        <img class="footer-about-logo" src="<?php echo e(logo_url()); ?>" />
                    <?php endif; ?>

                    <div class="clearfix"></div>
                    <?php echo nl2br(get_option('footer_about_us')); ?>

                </div>
            </div>

            <div class="col-md-3">
                <div class="footer-widget">
                    <h4 class="footer-widget-title">Contact Info </h4>
                    <ul class="contact-info">
                        <?php echo get_option('footer_address'); ?>

                    </ul>
                </div>
            </div>

            <div class="col-md-3">
                <div class="footer-widget">
                    <h4 class="footer-widget-title"><?php echo app('translator')->getFromJson('app.campaigns'); ?> </h4>
                    <ul class="contact-info">
                        <li><a href="<?php echo e(route('start_campaign')); ?>"><?php echo app('translator')->getFromJson('app.start_a_campaign'); ?></a> </li>
                        <li><a href="<?php echo e(route('browse_categories')); ?>"><?php echo app('translator')->getFromJson('app.discover_campaign'); ?></a> </li>
                        <li><a href="<?php echo e(route('checkout')); ?>"><?php echo app('translator')->getFromJson('app.checkout'); ?></a> </li>
                    </ul>
                </div>
            </div>

            <div class="col-md-3">
                <div class="footer-widget">
                    <h4 class="footer-widget-title"><?php echo app('translator')->getFromJson('app.about_us'); ?> </h4>
                    <ul class="contact-info">
                        <li><a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->getFromJson('app.home'); ?></a> </li>

                        <?php if($show_in_footer_menu->count() > 0): ?>
                            <?php $__currentLoopData = $show_in_footer_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('single_page', $page->slug)); ?>"><?php echo e($page->title); ?> </a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </ul>
                </div>
            </div>

        </div><!-- #row -->
    </div>


    <div class="container footer-bottom">
        <div class="row">
            <div class="col-md-12">
                <p class="footer-copyright"> <?php echo e(get_text_tpl(get_option('copyright_text'))); ?> </p>
            </div>
        </div>
    </div>


</footer>

<!-- Scripts -->
<script src="<?php echo e(asset('assets/js/jquery-1.11.2.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/masonry.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/toastr/toastr.min.js')); ?>"></script>

<!-- Conditional page load script -->
<?php if(request()->segment(1) === 'dashboard'): ?>
    <script src="<?php echo e(asset('assets/plugins/metisMenu/dist/metisMenu.min.js')); ?>"></script>
    <script>
        $(function() {
            $('#side-menu').metisMenu();
        });
    </script>
<?php endif; ?>
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
<script>
    var toastr_options = {closeButton : true};
</script>
<script>
    $('.box-campaign-lists').masonry({
        itemSelector : '.box-campaign-item'
    });
</script>
<?php echo $__env->yieldContent('page-js'); ?>

<?php if(get_option('additional_js')): ?>
<?php echo get_option('additional_js'); ?>

<?php endif; ?>

</body>
</html>
