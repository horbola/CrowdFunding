<?php $__env->startSection('title'); ?> <?php if(! empty($title)): ?> <?php echo e($title); ?> <?php endif; ?> - ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8## <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="page-wrapper">
        <div class="col-md-12">

                    <?php if( ! empty($title)): ?>
                        <div class="row">
                            <div class="col-lg-12">
                                <h1 class="page-header"> <?php echo e($title); ?>  </h1>
                            </div> <!-- /.col-lg-12 -->
                        </div> <!-- /.row -->
                    <?php endif; ?>

                    <?php echo $__env->make('admin.flash_msg', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


                       <table class="table table-bordered table-striped">
                           <tr>
                               <th><?php echo app('translator')->getFromJson('app.campaign_title'); ?></th>
                               <th><?php echo app('translator')->getFromJson('app.raised'); ?></th>
                               <th>Your Fund</th>
                           </tr>



                           <?php $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                               <tr>

                                   <td><?php echo e($campaign->title); ?></td>
                                   <td><?php echo e(get_amount($campaign->amount_raised()->amount_raised)); ?></td>
                                   <td><?php echo e(get_amount($campaign->amount_raised()->campaign_owner_commission)); ?> (<?php echo e($campaign->campaign_owner_commission); ?>%)</td>

                               </tr>


                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                       </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>