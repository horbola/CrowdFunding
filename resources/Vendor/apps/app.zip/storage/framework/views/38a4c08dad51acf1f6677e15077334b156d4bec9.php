<?php $__env->startSection('description', $campaign->short_description); ?>

<?php $__env->startSection('title'); ?> <?php if( ! empty($title)): ?> <?php echo e($title); ?> | <?php endif; ?> ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8##
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section class="campaign-details-wrap">

        <?php echo $__env->make('single_campaign_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="container">
            <div class="row">
                <div class="col-md-8">
                        <?php echo $__env->make('admin.flash_msg', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <div class="campaign-decription">
                            <div class="single-campaign-embeded">
                                <?php if( ! empty($campaign->video)): ?>
                                    <?php
                                    $video_url = $campaign->video;
                                    if (strpos($video_url, 'youtube') > 0) {
                                        preg_match("/^(?:http(?:s)?:\/\/)?(?:www\.)?(?:m\.)?(?:youtu\.be\/|youtube\.com\/(?:(?:watch)?\?(?:.*&)?v(?:i)?=|(?:embed|v|vi|user)\/))([^\?&\"'>]+)/", $video_url, $matches);
                                        if ( ! empty($matches[1])){
                                            echo '<div class="embed-responsive embed-responsive-16by9"><iframe class="embed-responsive-item" src="https://www.youtube.com/embed/'.$matches[1].'" frameborder="0" allowfullscreen></iframe></div>';
                                        }

                                    } elseif (strpos($video_url, 'vimeo') > 0) {
                                        if (preg_match('%^https?:\/\/(?:www\.|player\.)?vimeo.com\/(?:channels\/(?:\w+\/)?|groups\/([^\/]*)\/videos\/|album\/(\d+)\/video\/|video\/|)(\d+)(?:$|\/|\?)(?:[?]?.*)$%im', $video_url, $regs)) {
                                            if (!empty($regs[3])){
                                                echo '<div class="embed-responsive embed-responsive-16by9"><iframe class="embed-responsive-item" src="https://player.vimeo.com/video/'.$regs[3].'" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe></div>';
                                            }
                                        }
                                    }
                                    ?>
                                <?php else: ?>
                                    <div class="campaign-feature-img">
                                        <img src="<?php echo e($campaign->feature_img_url(true)); ?>" class="img-responsive" />
                                    </div>
                                <?php endif; ?>
                            </div>

                            <?php echo $campaign->description; ?>

                            <?php if($enable_discuss): ?>
                            <div class="post-footer">
                                <strong>Comments</strong>
                                <hr>
                            <div class="row">
                            <div class="col-md-10 col-md-offset-1 pt-20 pb-20 comment-main rounded">
                                <ul class="p-0">
                                    <?php if(count($campaign->comments)): ?>
                                    <?php $__currentLoopData = $campaign->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($comment->approved == 1 ): ?>
                                    <li>
                                        <div class="row comment-box p-20">
                                          <div class="col-lg-2 col-3 user-img text-center">
                                            <img src="<?php echo e($comment->user->get_gravatar(200)); ?>" class="main-cmt-img">
                                          </div>
                                          <div class="col-lg-10 col-9 user-comment bg-light rounded pb-1">
                                               <div class="row">
                                                     <div class="col-lg-8 col-6 border-bottom pr-0">
                                                        <p class="w-100 pt-15 pb-15 m-0"><?php echo e($comment->comment); ?></p>
                                                     </div>
                                                     <div class="col-lg-4 col-6 border-bottom">
                                                        <p class="w-100 p-2 m-0"><span class="float-right"><i class="fa fa-clock-o mr-1" aria-hidden="true"></i><?php echo e(date('d-m-Y', strtotime($comment->created_at))); ?></span></p>
                                                     </div>
                                               </div> 
                                          </div>
                                        </div>
                                    </li>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <hr>
                                    <?php endif; ?>
                                    <?php if(Auth::check()): ?>
                                    <div class="row">
                                      <div class="col-lg-10 col-10">
                                        <input type="text" class="form-control p-20 mt-5" id="commentmain" name="commentmain" placeholder="write comments ..." required="required">
                                      </div>
                                      <div class="col-lg-2 col-2 send-icon">
                                        <a href="javascript:void(0)" id="commentSubmit" onclick="commentSubmit('<?php echo e($campaign->id); ?>')" class="btn btn-success btn-sm"><i class="fa fa-paper-plane" aria-hidden="true"></i></a>
                                      </div>
                                    </div>
                                    <?php else: ?>
                                    <p class="warning"><a href="<?php echo e(route('login')); ?>">Login</a>/<a href="<?php echo e(route('register')); ?>">Register</a> for Give Comments</p>
                                    <?php endif; ?>
                                  </ul>
                            </div>
                            </div>    
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-md-4">
                    <?php echo $__env->make('campaign_single_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
    <script src="<?php echo e(asset('assets/plugins/SocialShare/SocialShare.min.js')); ?>"></script>
    <script>
        $('.share').ShareLink({
            title: '<?php echo e($campaign->title); ?>', // title for share message
            text: '<?php echo e($campaign->short_description ? $campaign->short_description : $campaign->description); ?>', // text for share message
            width: 640, // optional popup initial width
            height: 480 // optional popup initial height
        })
    </script>

    <script>
        $(function(){
            $(document).on('click', '.donate-amount-placeholder ul li', function(e){
                $(this).closest('form').find($('[name="amount"]')).val($(this).data('value'));
            });
        });

        function commentSubmit(id){
            var comment = $('#commentmain').val();
            $.ajax({
                type: 'POST',
                url: "<?php echo e(route('comments.store')); ?>",
                data: {'id': id, "_token": "<?php echo e(csrf_token()); ?>", 'comment':comment},
                success:function(response){
                    var data = $.parseJSON(response);
                    toastr.options = {
                      "debug": false,
                      "positionClass": "toast-top-full-width",
                      "onclick": null,
                      "fadeIn": 300,
                      "fadeOut": 1000,
                      "timeOut": 5000,
                      "extendedTimeOut": 1000
                    }
                    if(data.alert == 'success'){
                    toastr.success(data.message)}
                    if (data.alert == 'warning') {toastr.warning(data.message)}
                    $('#commentmain').val('')
                }

            });
        };
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.charity.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>